package com.example.dogfoodapp.Adapter;

public class ColorAdapter {
}
