package com.example.dogfoodapp.Domain;

public class SliderItems {
    private String url;

    public SliderItems(String url) {
        this.url = url;
    }

    public SliderItems() {

    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
