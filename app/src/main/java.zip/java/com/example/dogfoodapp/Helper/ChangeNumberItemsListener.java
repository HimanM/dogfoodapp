package com.example.dogfoodapp.Helper;

public interface ChangeNumberItemsListener {
    void changed();
}
